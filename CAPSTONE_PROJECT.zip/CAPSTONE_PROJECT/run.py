from app import app
from model.sql_alchemy_db import db
from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from chat import get_response
from controller.database_controller import DatabaseController
from controller.login import authorization
from controller.index import main_page
from controller.employee_controller import employee_controller
from controller.student_controller import student_controller
from controller.team_controller import team_controller
from controller.assignment_controller import assignment_controller
from controller.attendance_controller import attendance_controller
from controller.checkpoint_controller import checkpoint_controller
from controller.helpers import page_not_found, override_url_for

app = Flask(__name__)
CORS(app)


@app.get("/")
def index_get():
    return render_template("a.html")


@app.get("/a.html")
def a():
    return render_template("a.html")


@app.get("/about.html")
def about():
    return render_template("about.html")


@app.get("/news.html")
def news():
    return render_template("news.html")


@app.get("/contact.html")
def contact():
    return render_template("contact.html")


@app.post("/predict")
def predict():
    text = request.get_json().get("message")
    # todo check if text is valid
    response1, response2, response3 = get_response(text)
    response1 = str(response1)
    response2 = str(response2)
    response3 = str(response3)
    response = response1 + response2 + response3
    message = {"answer": response}
    return jsonify(message)


app.register_blueprint(authorization)
app.register_blueprint(employee_controller)
app.register_blueprint(student_controller)
app.register_blueprint(team_controller)
app.register_blueprint(assignment_controller)
app.register_blueprint(attendance_controller)
app.register_blueprint(checkpoint_controller)
app.register_blueprint(main_page)


if __name__ == "__main__":
    db.create_all()
    DatabaseController.sample_data()
    app.run(debug=True)
