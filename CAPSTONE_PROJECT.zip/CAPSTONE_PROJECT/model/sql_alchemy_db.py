from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy() # initialize db object