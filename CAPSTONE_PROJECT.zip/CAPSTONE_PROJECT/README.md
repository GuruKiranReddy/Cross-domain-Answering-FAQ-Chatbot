#CodeCool Management System

###Delivered to mentors, students and other staff by Team10
:squirrel:
