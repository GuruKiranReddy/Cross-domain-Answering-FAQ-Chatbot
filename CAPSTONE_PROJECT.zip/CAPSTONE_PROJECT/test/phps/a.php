<link rel="stylesheet" href="<?php echo url_for('/css/style.css') ?>" />

Hi <?php echo $C ?>. Do you know <?php echo $A ?> or <?php echo $B ?>?