class SerpApiClientException(Exception):
    pass