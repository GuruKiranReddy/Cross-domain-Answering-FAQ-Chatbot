from flask import Flask, render_template, request, jsonify
from flask_cors import CORS
from chat import get_response

app = Flask(__name__)
CORS(app)

@app.get("/")
def index_get():
    return render_template("base.html")

@app.post("/predict")
def predict():
    text = request.get_json().get("message")
    #todo check if text is valid
    response1,response2,response3 = get_response(text)
    response1 = str(response1)
    response2 = str(response2)
    response3 = str(response3)
    response = response1 + response2 + response3
    message = { "answer": response }
    return jsonify(message)

if __name__ == "__main__":
    app.run(debug=True)